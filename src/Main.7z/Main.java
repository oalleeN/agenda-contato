import ada.tech.agenda.visao.Menu;
import ada.tech.agenda.modelo.Contato;

public class Main {

    public static void main(String[] args) {

        int contador = 1 ;
        Contato[] contato = new Contato[contador];
        Contato[] contatoBackup = new Contato[contato.length];
        contato[0] = new Contato("Rafael", "Silva", "11997456560", "teste@dawda.com");
        System.out.println(contato[0]);

        for (int i = 0; i < contato.length; i++) {
            contatoBackup[i] = new Contato(contato[i].getNome(),contato[i].getSobreNome(),contato[i].getTelefone(),contato[i].getEmail());
        }

        contador = contatoBackup.length + 1;

        System.out.println(contador);

        contato[1] = new Contato("Luiz", "Silva", "11997456660", "teste@dawda.com");

    }

}
